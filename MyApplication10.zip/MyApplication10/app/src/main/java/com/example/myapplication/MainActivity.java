package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    CheckBox item1;
    CheckBox item2;
    CheckBox item3;
    CheckBox item4;
    CheckBox item5;

    TextView price;
    TextView tip;
    TextView sum;

    float p;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        price = findViewById(R.id.price);
        tip = findViewById(R.id.tip);
        sum = findViewById(R.id.sum);

        item1 = findViewById(R.id.item1);
        item2 = findViewById(R.id.item2);
        item3 = findViewById(R.id.item3);
        item4 = findViewById(R.id.item4);
        item5 = findViewById(R.id.item5);

        item1.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if(isChecked) {
                p += 15;
            } else {
                p -= 15;
            }

            price.setText(p + " zł");
            tip.setText(p * 0.10 + " zł");
            sum.setText(p * 1.10 + " zł");
        });
        item2.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if(isChecked) {
                p += 16;
            } else {
                p -= 16;
            }

            price.setText(p + " zł");
            tip.setText(p * 0.10 + " zł");
            sum.setText(p * 1.10 + " zł");
        });
        item3.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if(isChecked) {
                p += 13;
            } else {
                p -= 13;
            }

            price.setText(p + " zł");
            tip.setText(p * 0.10 + " zł");
            sum.setText(p * 1.10 + " zł");
        });
        item4.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if(isChecked) {
                p += 17;
            } else {
                p -= 17;
            }

            price.setText(p + " zł");
            tip.setText(p * 0.10 + " zł");
            sum.setText(p * 1.10 + " zł");
        });
        item5.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if(isChecked) {
                p += 30;
            } else {
                p -= 30;
            }

            price.setText(p + " zł");
            tip.setText(p * 0.10 + " zł");
            sum.setText(p * 1.10 + " zł");
        });

    }
}